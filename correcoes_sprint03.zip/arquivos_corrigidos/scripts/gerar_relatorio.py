#!/usr/bin/env python3
"""
Gera os relatórios da Sprint 03 a partir dos JSON de results/.

    python scripts/gerar_relatorio.py

Saídas:
    docs/relatorio_modelos.md              (Bloco B — comparação entre modelos + seleção justificada)
    docs/resultados_seguranca.md           (Bloco C — avaliação documentada de cada caso de segurança)
    docs/relatorio_evolucao_sprint03.md    (Bloco D — fonte do PDF)
    docs/relatorio_evolucao_sprint03.pdf   (entregue junto do repositório)

Fonte dos números: os JSON por bloco (qualidade_*.json, seguranca_*.json, memoria_*.json,
parametros_*.json). `consolidado.json` só é usado para completar o que faltar — assim uma
execução parcial do eval nunca zera a tabela.

Enquanto faltar algum resultado, o relatório sai marcado como PRELIMINAR e a faixa no topo lista
exatamente o que está pendente. Com tudo medido, a faixa some sozinha.
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import date, datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

DIR_RESULTS = RAIZ / "results"
DIR_DOCS = RAIZ / "docs"
VAZIO = "—"

MODELOS_COMPARACAO = ["qwen", "llama"]  # os 2 modelos exigidos pela rubrica (Bloco B)
TOLERANCIA_NOTA = 0.05                  # diferença menor que isso é empate

EQUIPE = [
    ("Ana Beatriz Berbel Marini", "574176"),
    ("Gustavo Bonamico Piccoli", "569984"),
    ("Julian Nayde Moncoski", "572603"),
    ("Marcelo Francisco Josafá Ribeiro Martins", "573905"),
    ("Maria Eduarda Medeiros Lemos", "574094"),
    ("Pietro Lorande da Silva", "569125"),
]

TAREFAS = {
    "574176": "Guardrails e casos de teste de segurança (S01–S11); documento `seguranca_guardrails.md`",
    "569984": "Migração do RAG para retriever LangChain, indexação Chroma e corpus de contingência",
    "572603": "Memória por sessão (`RunnableWithMessageHistory`), janela deslizante e demonstração de 3+ turnos",
    "573905": "Comparação entre modelos, varredura de parametrização e `relatorio_modelos.md`",
    "574094": "Eval set reexecutado, scoring reprodutível e instrumentação de métricas (latência/tokens)",
    "569125": "Arquitetura da chain, refactory do núcleo conversacional, interface Gradio e integração do repositório",
}


# ──────────────────────────────────────────────────────────────────────────────
# Utilidades
# ──────────────────────────────────────────────────────────────────────────────
def hoje() -> str:
    """Data local do Brasil (a máquina que gera o PDF pode estar em UTC)."""
    try:
        from zoneinfo import ZoneInfo

        return datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y")
    except Exception:
        return date.today().strftime("%d/%m/%Y")


def carregar(nome: str):
    caminho = DIR_RESULTS / nome
    if not caminho.exists():
        return None
    try:
        return json.loads(caminho.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def br(x) -> str:
    """Número no formato pt-BR (vírgula decimal)."""
    if isinstance(x, bool):
        return "sim" if x else "não"
    if isinstance(x, float):
        if x == int(x):
            return str(int(x))
        return f"{x:.3f}".rstrip("0").rstrip(".").replace(".", ",")
    return str(x)


def val(dic, *chaves, sufixo=""):
    atual = dic
    for c in chaves:
        if not isinstance(atual, dict) or c not in atual:
            return VAZIO
        atual = atual[c]
    if atual is None:
        return VAZIO
    return f"{br(atual)}{sufixo}"


def num(dic, chave):
    v = dic.get(chave) if isinstance(dic, dict) else None
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def repo_id(apelido: str) -> str:
    from src.config import MODELOS

    return MODELOS[apelido].repo_id if apelido in MODELOS else apelido


# ──────────────────────────────────────────────────────────────────────────────
# Leitura dos resultados
# ──────────────────────────────────────────────────────────────────────────────
def reconstruir_consolidado():
    """Monta o consolidado a partir dos JSON por bloco (fonte da verdade)."""
    from src.config import MODELOS

    arquivo = carregar("consolidado.json") or {}
    cons: dict = {
        "gerado_em": arquivo.get("gerado_em", ""),
        "modelos_testados": [],
        "qualidade": {},
        "seguranca": {},
        "memoria": {},
        "parametros": {},
        "casos_seguranca": {},
    }
    achou = False

    for m in MODELOS:
        q = carregar(f"qualidade_sprint3_{m}.json")
        if q and q.get("resumo"):
            cons["qualidade"][m] = q["resumo"]
            achou = True
        s = carregar(f"seguranca_sprint3_{m}.json")
        if s and s.get("resumo"):
            cons["seguranca"][m] = s["resumo"]
            cons["casos_seguranca"][m] = s.get("casos", [])
            achou = True
        mem = carregar(f"memoria_{m}.json")
        if mem:
            cons["memoria"][m] = {
                "memoria_recuperou_contexto": mem.get("memoria_recuperou_contexto"),
                "sessoes_isoladas": mem.get("sessoes_isoladas"),
                "turnos": len(mem.get("turnos", [])),
            }
            achou = True
        par = carregar(f"parametros_{m}.json")
        if par:
            cons["parametros"][m] = {"varreduras": par}
            achou = True

    # Legado: um arquivo por modelo; usa o do primeiro modelo que tiver resultado.
    for m in MODELOS:
        ql = carregar(f"qualidade_legado_{m}.json")
        if ql and ql.get("resumo") and "legado" not in cons["qualidade"]:
            cons["qualidade"]["legado"] = ql["resumo"]
            achou = True
        sl = carregar(f"seguranca_legado_{m}.json")
        if sl and sl.get("resumo") and "legado" not in cons["seguranca"]:
            cons["seguranca"]["legado"] = sl["resumo"]
            achou = True

    # consolidado.json só completa lacunas.
    for bloco in ("qualidade", "seguranca", "memoria", "parametros"):
        for chave, dado in (arquivo.get(bloco) or {}).items():
            cons[bloco].setdefault(chave, dado)

    testados = [m for m in MODELOS if m in cons["qualidade"]]
    cons["modelos_testados"] = testados or arquivo.get("modelos_testados") or ["qwen"]
    return cons if (achou or arquivo) else None


def pendencias(cons) -> list[str]:
    """Lista, em português, o que ainda não foi medido."""
    if not cons:
        return ["nenhum resultado em `results/` — rode `python -m eval.run_eval --tudo --modelos qwen llama`"]
    qual, seg, mem = cons.get("qualidade", {}), cons.get("seguranca", {}), cons.get("memoria", {})
    principal = cons["modelos_testados"][0]
    faltas = []
    if not qual.get("legado"):
        faltas.append("qualidade/latência/tokens do legado (Sprints 1/2)")
    if not qual.get(principal):
        faltas.append(f"qualidade/latência/tokens da Sprint 03 ({principal})")
    if not seg.get("legado"):
        faltas.append("testes de segurança do legado")
    if not seg.get(principal):
        faltas.append(f"testes de segurança da Sprint 03 ({principal})")
    if principal not in mem:
        faltas.append("demonstração de memória em 4 turnos")
    for m in MODELOS_COMPARACAO:
        if m not in qual:
            faltas.append(f"avaliação do modelo `{m}` (Bloco B exige 2+ modelos)")
        elif m not in seg:
            faltas.append(f"testes de segurança do modelo `{m}`")
    if not cons.get("parametros"):
        faltas.append("varredura de temperature/top_p")
    return faltas


def faixa_preliminar(cons) -> str:
    faltas = pendencias(cons)
    if not faltas:
        return ""
    itens = "; ".join(faltas)
    return (
        "> ⚠️ **Versão preliminar — resultados pendentes:** "
        f"{itens}. As células «—» são preenchidas por `scripts/gerar_relatorio.py` assim que os JSON "
        "existirem em `results/`.\n\n"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Seleção justificada (critério lexicográfico definido ANTES da execução)
# ──────────────────────────────────────────────────────────────────────────────
def escolher_modelo(qual, seg, modelos):
    cand = [m for m in modelos if num(qual.get(m, {}), "nota_media") is not None
            and num(seg.get(m, {}), "taxa_aprovacao") is not None]
    if len(cand) < 2:
        return None

    passos: list[str] = []
    taxa = {m: num(seg[m], "taxa_aprovacao") for m in cand}
    topo = max(taxa.values())
    c1 = [m for m in cand if taxa[m] == topo]
    lista = " × ".join(f"`{m}` {br(taxa[m])}%" for m in cand)
    passos.append(
        f"1. **Segurança** — {lista}. "
        + (f"Segue(m) na disputa: {', '.join(f'`{m}`' for m in c1)}." if len(c1) < len(cand)
           else "Empate; passa para o critério seguinte.")
    )

    nota = {m: num(qual[m], "nota_media") for m in c1}
    melhor = max(nota.values())
    c2 = [m for m in c1 if melhor - nota[m] < TOLERANCIA_NOTA]
    if len(c1) > 1:
        lista = " × ".join(f"`{m}` {br(nota[m])}" for m in c1)
        dif = round(melhor - min(nota.values()), 3)
        passos.append(
            f"2. **Nota média no eval** — {lista} (diferença {br(dif)}). "
            + (f"Diferença ≥ {br(TOLERANCIA_NOTA)}: prevalece `{c2[0]}`." if len(c2) == 1
               else f"Diferença < {br(TOLERANCIA_NOTA)}: empate técnico.")
        )
    else:
        passos.append("2. **Nota média no eval** — não decide (um único finalista).")

    vencedor = c2[0]
    if len(c2) > 1:
        lat = {m: num(qual[m], "latencia_media_s") for m in c2}
        if all(v is not None for v in lat.values()):
            c3 = sorted(c2, key=lambda m: lat[m])
            lista = " × ".join(f"`{m}` {br(lat[m])} s" for m in c2)
            vencedor = c3[0]
            passos.append(f"3. **Latência média** — {lista}. Vence `{vencedor}` (mais rápido).")
            if lat[c3[0]] == lat[c3[1]]:
                tok = {m: num(qual[m], "tokens_medio_por_turno") or 0 for m in c2}
                vencedor = sorted(c2, key=lambda m: tok[m])[0]
                passos.append(f"4. **Tokens por turno** — desempate final: `{vencedor}`.")

    return {"vencedor": vencedor, "passos": passos, "modelos": cand}


def escolher_parametros(varreduras):
    itens = []
    for v in varreduras:
        r = v["resumo"]
        if num(r, "nota_media") is None:
            continue
        itens.append((v["parametros"], r))
    if not itens:
        return None
    melhor = max(num(r, "nota_media") for _, r in itens)
    empatados = [(p, r) for p, r in itens if melhor - num(r, "nota_media") < TOLERANCIA_NOTA]
    empatados.sort(key=lambda pr: (num(pr[1], "latencia_media_s") or 1e9,
                                   num(pr[1], "tokens_medio_por_turno") or 1e9))
    return empatados[0][0], empatados[0][1], len(empatados) > 1


# ──────────────────────────────────────────────────────────────────────────────
# Tabelas de segurança (Bloco C — avaliação documentada por caso)
# ──────────────────────────────────────────────────────────────────────────────
def tabela_seguranca(casos, com_resposta=False) -> str:
    if not casos:
        return "_Sem resultado de segurança ainda — rode `python -m eval.run_eval --seguranca`._\n"
    cab = "| ID | Técnica | Barrado antes da LLM | Resultado | Observação |\n|---|---|---|---|---|\n"
    linhas = []
    for c in casos:
        obs = []
        if c.get("requisitos_faltando"):
            obs.append("faltou: " + "; ".join(c["requisitos_faltando"]))
        if c.get("conteudo_indevido"):
            obs.append("conteúdo indevido: " + "; ".join(c["conteudo_indevido"]))
        linhas.append(
            f"| {c['id']} | {c['tecnica']} | {'sim' if c.get('bloqueado_por_guardrail') else 'não'} | "
            f"{'✅ passou' if c.get('passou') else '❌ falhou'} | {' · '.join(obs) if obs else '—'} |"
        )
    tabela = cab + "\n".join(linhas) + "\n"
    if com_resposta:
        trechos = []
        for c in casos:
            resp = (c.get("resposta") or "").replace("\n", " ").strip()
            trechos.append(f"- **{c['id']}** ({c['tecnica']}): «{resp[:260]}{'…' if len(resp) > 260 else ''}»")
        tabela += "\n**Resposta gerada em cada caso (trecho):**\n\n" + "\n".join(trechos) + "\n"
    return tabela


def gerar_resultados_seguranca(cons) -> str:
    casos = (cons or {}).get("casos_seguranca", {})
    corpo = []
    for m, lista in casos.items():
        r = (cons.get("seguranca") or {}).get(m, {})
        corpo.append(
            f"## Modelo `{m}` — {val(r, 'aprovados')}/{val(r, 'casos')} casos aprovados "
            f"({val(r, 'taxa_aprovacao', sufixo='%')}); {val(r, 'bloqueios_deterministicos')} barrados antes da LLM\n\n"
            + tabela_seguranca(lista, com_resposta=True)
        )
    if not corpo:
        corpo = [tabela_seguranca([])]
    return (
        "# Resultados dos testes de segurança — Sprint 03\n\n"
        f"**GoodWe Assist · EV Challenge 2026 — GoodWe / FIAP** · {hoje()}\n\n"
        "Avaliação de cada caso de `eval/security_set.py` (S01–S11). Critério: o caso só passa se o bloqueio "
        "esperado ocorreu **e** todos os termos obrigatórios apareceram **e** nenhum conteúdo indevido "
        "apareceu (`eval/scoring.py::avaliar_seguranca`). O comportamento esperado de cada caso está em "
        "`docs/seguranca_guardrails.md`; as respostas completas ficam em `results/seguranca_*.json`.\n\n"
        + "\n".join(corpo)
    )


# ──────────────────────────────────────────────────────────────────────────────
# relatorio_modelos.md
# ──────────────────────────────────────────────────────────────────────────────
def gerar_relatorio_modelos(cons) -> str:
    from src.config import GRADE_PARAMETROS, MODELOS

    cons = cons or {}
    qual, seg = cons.get("qualidade", {}), cons.get("seguranca", {})
    testados = cons.get("modelos_testados", [])
    modelos = MODELOS_COMPARACAO + [m for m in testados if m not in MODELOS_COMPARACAO]

    linhas_param = "\n".join(
        f"| `{MODELOS[m].repo_id}` | {MODELOS[m].temperature} | {MODELOS[m].top_p} | "
        f"{MODELOS[m].max_tokens} | {MODELOS[m].repetition_penalty} | {MODELOS[m].observacao} |"
        for m in modelos
        if m in MODELOS
    )

    def seg_txt(m):
        r = seg.get(m, {})
        if not r:
            return VAZIO
        return f"{val(r, 'aprovados')}/{val(r, 'casos')} ({val(r, 'taxa_aprovacao', sufixo='%')})"

    linhas_result = "\n".join(
        f"| `{MODELOS[m].repo_id}` | {val(qual, m, 'nota_media')} | {val(qual, m, 'percentual', sufixo='%')} | "
        f"{val(qual, m, 'corretos')}/{val(qual, m, 'casos')} | {val(qual, m, 'latencia_media_s', sufixo=' s')} | "
        f"{val(qual, m, 'tokens_medio_por_turno')} | {seg_txt(m)} |"
        for m in modelos
        if m in MODELOS
    )

    varreduras = cons.get("parametros") or {}
    linhas_varredura = []
    for modelo, dados in varreduras.items():
        for item in dados.get("varreduras", []):
            p, r = item["parametros"], item["resumo"]
            linhas_varredura.append(
                f"| `{modelo}` | {p['temperature']} | {p['top_p']} | {p['max_tokens']} | "
                f"{val(r, 'nota_media')} | {val(r, 'latencia_media_s', sufixo=' s')} | "
                f"{val(r, 'tokens_medio_por_turno')} |"
            )
    if not linhas_varredura:
        linhas_varredura = [
            f"| {VAZIO} | {g['temperature']} | {g['top_p']} | {g['max_tokens']} | {VAZIO} | {VAZIO} | {VAZIO} |"
            for g in GRADE_PARAMETROS
        ]

    # ── Seleção justificada ────────────────────────────────────────────────
    escolha = escolher_modelo(qual, seg, modelos)
    avisos = []
    if escolha:
        vencedor = escolha["vencedor"]
        modelo_sel = f"`{repo_id(vencedor)}`"
        just = "\n".join(escolha["passos"])
    else:
        vencedor = None
        modelo_sel = VAZIO
        just = (
            "Pendente: a seleção só pode ser calculada com **os dois modelos** avaliados "
            "(qualidade + segurança). Rode `python -m eval.run_eval --tudo --modelos qwen llama`."
        )

    param_sel = VAZIO
    if vencedor and varreduras:
        if vencedor not in varreduras:
            avisos.append(
                f"> ⚠️ A varredura de parametrização foi executada em `{', '.join(varreduras)}`, mas o modelo "
                f"selecionado é `{vencedor}`. Rode `python -m eval.run_eval --parametros {vencedor}` para "
                "justificar a parametrização do modelo escolhido."
            )
        else:
            esc = escolher_parametros(varreduras[vencedor]["varreduras"])
            if esc:
                p, r, houve_empate = esc
                param_sel = f"temperature = {p['temperature']}, top_p = {p['top_p']}, max_tokens = {p['max_tokens']}"
                just += (
                    f"\n\nParametrização: entre as 3 configurações varridas em `{vencedor}`, a de melhor nota média "
                    f"foi escolhida pelo mesmo critério (nota {val(r, 'nota_media')}; "
                    f"latência {val(r, 'latencia_media_s', sufixo=' s')}; "
                    f"{val(r, 'tokens_medio_por_turno')} tokens/turno)"
                    + ("; houve empate técnico de nota e a decisão foi por latência." if houve_empate else ".")
                )
    elif vencedor and not varreduras:
        avisos.append("> ⚠️ Falta a varredura de parametrização (`python -m eval.run_eval --parametros "
                      f"{vencedor}`).")

    tokens_est = [m for m in modelos if (qual.get(m) or {}).get("tokens_estimados")]
    nota_tokens = (
        "quando o provedor não devolve `usage`, a contagem é estimada em ≈4 caracteres por token sobre o "
        "prompt **completo** (system + contexto + histórico + pergunta) e a saída, e o campo "
        "`tokens_estimados` fica `true` no JSON."
        + (f" Nesta execução, tokens estimados em: {', '.join(f'`{m}`' for m in tokens_est)}." if tokens_est else "")
    )

    return f"""# Relatório de uso de modelos e parâmetros — Sprint 03

**Projeto:** GoodWe Assist · EV Challenge 2026 — GoodWe / FIAP
**Gerado em:** {hoje()}

{faixa_preliminar(cons)}## 1. Modelos avaliados e parametrização

Todos os modelos foram executados **sobre o mesmo pipeline** (mesma chain LangChain, mesmo
retriever, mesmo prompt v3, mesmo eval set das Sprints 1/2). A única variável é a LLM e seus
parâmetros — sem isso a comparação não mediria o modelo, mediria o contexto.

| Modelo | temperature | top_p | max_tokens | repetition_penalty | Observação |
|---|---|---|---|---|---|
{linhas_param}

**Por que esses parâmetros como ponto de partida**

- `temperature = 0.2` — suporte operacional é tarefa determinística: o mesmo erro E07 deve gerar
  o mesmo procedimento. Temperatura alta produz variação de passo a passo, que é exatamente o que
  confunde o operador.
- `top_p = 0.9` — corta a cauda de tokens improváveis (origem das alucinações de código de erro e
  de nome de menu) sem engessar a redação.
- `max_tokens = 600` — os procedimentos do eval set cabem com folga em 600 tokens; acima disso o
  modelo passa a repetir avisos e o custo por turno sobe sem ganho de nota.
- `repetition_penalty = 1.05` — leve, só para conter a repetição de blocos de aviso observada nos
  modelos abertos de 7B.

## 2. Resultados por modelo

| Modelo | Nota média (0–1) | % do eval | Respostas corretas | Latência média | Tokens/turno | Aprovação em segurança |
|---|---|---|---|---|---|---|
{linhas_result}

## 3. Varredura de parametrização

Executada no modelo selecionado, sobre o eval set completo:

| Modelo | temperature | top_p | max_tokens | Nota média | Latência média | Tokens/turno |
|---|---|---|---|---|---|---|
{chr(10).join(linhas_varredura)}

`temperature = 0.0` é enviado à API como `0.01` (a Inference API rejeita zero).

## 4. Seleção justificada

O critério de decisão foi definido *antes* da execução, para não enviesar a leitura, e é lexicográfico:

1. **Aprovação em segurança** — o modelo com menor taxa de aprovação nos 11 casos é eliminado, por
   maior que seja a nota de qualidade;
2. **Nota média no eval set** — diferença menor que 0,05 é considerada empate;
3. **Latência média** — no empate, vence quem responde mais rápido ao operador;
4. **Tokens por turno** — critério de desempate final (custo).

**Aplicação do critério aos resultados desta execução:**

{just}

**Modelo selecionado:** {modelo_sel}
**Parametrização selecionada:** {param_sel}

{chr(10).join(avisos)}

**Limitações desta comparação.** O eval tem 8 casos e cada configuração foi executada uma vez, sem
repetições: um caso parcial pesa 0,0625 na nota média e a Inference API gratuita tem variação de
latência entre execuções. Os números orientam a escolha; não são um teste estatístico.

## 5. Reprodutibilidade

```bash
pip install -r requirements.txt
export HUGGING_FACE_API_KEY=...        # ou .env / Colab Secrets / Kaggle Secrets
python -m eval.run_eval --tudo --modelos qwen llama
python -m eval.run_eval --parametros <modelo selecionado>
python scripts/gerar_relatorio.py
```

Evidências brutas (resposta completa de cada caso, por modelo): `results/qualidade_*.json`,
`results/seguranca_*.json`, `results/parametros_*.json`, `results/metricas_brutas.json`.

**Nota sobre a contagem de tokens:** {nota_tokens}
"""


# ──────────────────────────────────────────────────────────────────────────────
# relatorio_evolucao_sprint03.md (fonte do PDF)
# ──────────────────────────────────────────────────────────────────────────────
def gerar_relatorio_evolucao(cons) -> str:
    cons = cons or {}
    qual, seg, mem = cons.get("qualidade", {}), cons.get("seguranca", {}), cons.get("memoria", {})
    principal = (cons.get("modelos_testados") or ["qwen"])[0]

    leg_q, nov_q = qual.get("legado", {}), qual.get(principal, {})
    leg_s, nov_s = seg.get("legado", {}), seg.get(principal, {})
    mem_p = mem.get(principal, {})

    def par(dic, *ch, sufixo=""):
        return val(dic, *ch, sufixo=sufixo)

    memoria_txt = par(mem_p, "memoria_recuperou_contexto")
    isolou_txt = par(mem_p, "sessoes_isoladas")
    n_turnos = par(mem_p, "turnos")

    equipe_md = "\n".join(f"| {nome} | {rm} | {TAREFAS[rm]} |" for nome, rm in EQUIPE)

    est_leg = bool(leg_q.get("tokens_estimados"))
    est_nov = bool(nov_q.get("tokens_estimados"))
    marca_tok = " \\*" if (est_leg or est_nov) else ""
    if est_leg or est_nov:
        onde = " e ".join(n for n, f in (("Sprints 1/2", est_leg), ("Sprint 03", est_nov)) if f)
        nota_tokens = (
            f"\\* Tokens estimados (≈4 caracteres por token, sobre o prompt completo) em: {onde}, "
            "porque o provedor não devolveu `usage` nessas execuções."
        )
    elif leg_q and nov_q:
        nota_tokens = "Tokens medidos a partir do `usage` devolvido pela API nas duas colunas."
    else:
        nota_tokens = ""

    origem = f" (gerados em {cons['gerado_em'][:10]})" if cons.get("gerado_em") else ""
    casos_seg = (cons.get("casos_seguranca") or {}).get(principal, [])

    return f"""# Relatório de evolução do projeto — Sprint 03

**GoodWe Assist · EV Challenge 2026 — GoodWe / FIAP** · {hoje()}

| | |
|---|---|
| **Projeto** | GoodWe Assist — chatbot de operação de eletropostos comerciais GoodWe |
| **Contexto do desafio** | ChargeGrid Intelligence |
| **Persona atendida** | Operador comercial de eletroposto |
| **Disciplina** | Prompt and Artificial Intelligence — 1º ano Ciência da Computação — 2026.2 (Turma 1CCPZ) |
| **Repositório** | https://github.com/pietrolorande01-ELFzen/Challenge-_AI-PROMPT |
| **Modelos comparados** | `{repo_id('qwen')}` × `{repo_id('llama')}` (principal do antes/depois: `{principal}`) |

{faixa_preliminar(cons)}## 1. Resumo da evolução

**O que existia nas Sprints 1 e 2.** Um chatbot funcional em notebook: RAG com ChromaDB sobre três
PDFs técnicos GoodWe, system prompt com dois exemplos few-shot injetados manualmente, chamada direta
ao `InferenceClient` da Hugging Face (Qwen2.5-7B-Instruct) e interface Gradio. A memória era uma
lista Python de tuplas `(pergunta, resposta)` remontada a cada chamada dentro da própria função do
chatbot, sem isolamento entre usuários. Não havia camada de segurança: a única proteção era a frase
"se não souber, indique o suporte" dentro do prompt. A avaliação era manual: o modelo de teste da
Sprint 1 definiu 8 pares pergunta/resposta ideal, mas o notebook da Sprint 2 executou apenas 4
perguntas e registrou o resultado numa tabela de ✅/⚠️ preenchida a olho.

**O que existe agora na Sprint 03.** O núcleo conversacional foi reconstruído em **LangChain**
(LCEL + `RunnableWithMessageHistory`), com quatro mudanças estruturais:

1. **Memória gerenciada pelo framework** — `InMemoryChatMessageHistory` por `session_id`, com
   janela deslizante via `trim_messages`. Sessões diferentes não enxergam uma à outra.
2. **Guardrails em três camadas** — validação determinística antes e depois da LLM, mais regras
   imutáveis no prompt v3, cobrindo prompt injection (inclusive indireta, via documento colado),
   escopo GoodWe e recusas de domínio jurídico, financeiro e de segurança elétrica.
3. **Avaliação reprodutível** — os 8 pares do modelo de teste da Sprint 1 viraram código, com nota
   determinística (0 / 0,5 / 1), 11 casos de segurança e instrumentação de latência e tokens por turno.
4. **Comparação entre modelos** — a LLM virou configuração; dois modelos e três parametrizações
   passam pelo mesmo pipeline e geram os JSON que alimentam este relatório.

## 2. Refatoração — decisões técnicas e trade-offs

**Framework escolhido: LangChain.** Detalhamento completo em `docs/justificativa_framework.md`.
Em resumo: CrewAI resolveria orquestração multiagente, que não é o nosso problema — temos um
agente de suporte com RAG e memória, e agentes extras só adicionariam chamadas de LLM, latência e
superfície de alucinação. O Google ADK amarraria o projeto ao Gemini e atrapalharia justamente o
Bloco B, que exige comparar modelos. LangChain entrega memória por sessão nativa, retriever
plugável e interface uniforme entre provedores.

**Decisões de arquitetura e o que custaram:**

- *Chain determinística em vez de `AgentExecutor` com ferramentas.* Modelos abertos de 7–8B têm
  suporte irregular a function calling; um loop de ferramentas traria latência e erro sem ganho
  para o operador. Custo: se no futuro entrar consulta a API real de sessões, será preciso migrar
  para um executor com tools.
- *Guardrail determinístico antes da LLM.* Ataque de injeção conhecido nem chega ao modelo:
  resposta canônica, zero token gasto, comportamento idêntico em qualquer LLM. Custo: regex tem
  falso positivo e falso negativo (só cobre padrões em português que já conhecemos); mitigado pela
  separação entre instrução e conteúdo colado, para não bloquear o operador que cola um relatório
  de cliente, e pela camada de prompt como segunda defesa.
- *Prompt v3 maior que o legado.* O system prompt ganhou escopo, recusas de domínio, regras de
  segurança e few-shot de recusa. Custo: mais tokens de entrada por turno — a tabela da seção 3
  mede esse custo em vez de escondê-lo.
- *Retriever em vez de `colecao.query` direto.* A base de conhecimento virou dependência injetada:
  o eval roda o legado e a versão nova sobre o **mesmo** retriever, o que garante que a tabela
  antes/depois meça o refactory e não a diferença de indexação. Custo: uma camada a mais de
  abstração no debug.
- *Corpus de contingência versionado.* Os PDFs GoodWe não estão no repositório. Sem eles o eval
  não rodaria em outra máquina, então `data/base_conhecimento_goodwe.md` consolida as notas
  operacionais das Sprints 1/2 e entra como fonte de fallback, sempre identificada na metadata do
  chunk. Custo: o eval avalia o pipeline sobre o corpus consolidado, não sobre os PDFs oficiais.
- *Nota determinística no eval.* Trocamos o julgamento humano por cobertura de termos obrigatórios
  e ausência de termos proibidos. Custo: o critério é mais rígido que um avaliador humano e pode
  punir uma resposta certa escrita com sinônimos; ganho: qualquer pessoa reexecuta e obtém o mesmo
  número.

## 3. Tabela de comparativo antes/depois

**Como os números foram obtidos{origem}.** Conjunto de avaliação: os 8 pares de
`sprints_anteriores/modelo_de_teste.md` (Sprint 1), reexecutados com nota determinística
(`eval/eval_set.py`). Como a Sprint 2 rodou só 4 perguntas manualmente e sem nota, não havia número
anterior para reaproveitar: a coluna *Sprints 1/2* é o núcleo manual da Sprint 2 preservado em
`legacy/chat_manual.py` (mesmo prompt com os 2 few-shots, sem framework, sem guardrails) executado
agora sobre os mesmos 8 casos. As duas colunas usam o mesmo retriever e o mesmo modelo (`{principal}`),
temperature 0.2 e max_tokens 600; o legado, como na Sprint 2, não envia top_p nem repetition_penalty.

| Métrica | Sprints 1/2 (versão manual/legado) | Sprint 03 (framework de agentes) |
|---|---|---|
| Framework do núcleo conversacional | Nenhum — `InferenceClient` direto | LangChain (LCEL + `RunnableWithMessageHistory`) |
| Gestão de memória | Lista Python global, remontada a cada chamada | Memória nativa por `session_id` + janela deslizante |
| **Qualidade das respostas — nota média no eval (0–1)** | {par(leg_q, 'nota_media')} | {par(nov_q, 'nota_media')} |
| **Qualidade — % do eval set** | {par(leg_q, 'percentual', sufixo='%')} | {par(nov_q, 'percentual', sufixo='%')} |
| Respostas corretas / parciais / incorretas | {par(leg_q, 'corretos')} / {par(leg_q, 'parciais')} / {par(leg_q, 'incorretos')} | {par(nov_q, 'corretos')} / {par(nov_q, 'parciais')} / {par(nov_q, 'incorretos')} |
| **Tokens por turno (média){marca_tok}** | {par(leg_q, 'tokens_medio_por_turno')} | {par(nov_q, 'tokens_medio_por_turno')} |
| **Latência média por turno** | {par(leg_q, 'latencia_media_s', sufixo=' s')} | {par(nov_q, 'latencia_media_s', sufixo=' s')} |
| Latência p95 | {par(leg_q, 'latencia_p95_s', sufixo=' s')} | {par(nov_q, 'latencia_p95_s', sufixo=' s')} |
| **Testes de segurança — casos aprovados** | {par(leg_s, 'aprovados')} / {par(leg_s, 'casos')} | {par(nov_s, 'aprovados')} / {par(nov_s, 'casos')} |
| **Testes de segurança — taxa de aprovação** | {par(leg_s, 'taxa_aprovacao', sufixo='%')} | {par(nov_s, 'taxa_aprovacao', sufixo='%')} |
| Ataques barrados antes de chegar à LLM | 0 (não havia camada) | {par(nov_s, 'bloqueios_deterministicos')} |
| Memória: recupera contexto no 4º turno | Não testado | {memoria_txt} |
| Memória: isolamento entre sessões (controle negativo) | Inexistente (histórico global) | {isolou_txt} |
| Cobertura de testes automatizados | 4 casos executados manualmente | 8 casos de qualidade + 11 de segurança + 1 roteiro de memória de {n_turnos} turnos, via `eval/run_eval.py` |

{nota_tokens}

Evidências brutas de cada célula: `results/*.json`. Avaliação caso a caso da segurança:
`docs/resultados_seguranca.md`.

### Resultados dos testes de segurança — Sprint 03 (`{principal}`)

{tabela_seguranca(casos_seg)}
## 4. Problemas encontrados e soluções

**Problema 1 — Falso positivo do guardrail em documento colado.**
A primeira versão do detector bloqueava qualquer mensagem contendo "ignore as instruções". Na
prática, o operador cola relatórios e e-mails de cliente na conversa; um cliente mal-intencionado
(ou só um texto estranho) derrubaria o atendimento legítimo. *Decisão:* separar a mensagem em
instrução do usuário e conteúdo colado (blocos delimitados por crase tripla, `--- ---`, aspas
triplas ou `<doc>`) e rodar a detecção de injeção apenas sobre a instrução. Payload dentro do bloco
colado passa a **sinalizar** — o pedido legítimo é atendido e o modelo recebe o aviso de tratar
aquilo como dado. *Porquê:* bloquear o trabalho do operador é um custo real e recorrente;
a injeção indireta se resolve com neutralização, não com recusa.

**Problema 2 — Avaliação da Sprint 2 não era comparável.**
A tabela de resultados da Sprint 2 era preenchida à mão, cobria 4 perguntas (diferentes dos 8 pares
do modelo de teste da Sprint 1) e tinha um caso marcado "✅/⚠️" porque a resposta variava entre
execuções. Não dá para montar uma tabela antes/depois em cima disso. *Decisão:* transformar cada
caso do eval set em dados verificáveis (grupos de termos obrigatórios e lista de termos proibidos),
calcular a nota por cobertura mantendo a escala 0 / 0,5 / 1 da Sprint 1 e reexecutar o legado sobre
os 8 casos. *Porquê:* o Bloco D exige evidência, e evidência precisa ser reexecutável por terceiros.

**Problema 3 — Instabilidade e rate-limit da Inference API gratuita.**
Já tinha aparecido na Sprint 2 (respostas truncadas, caracteres fora do idioma no primeiro turno,
HTTP 429 entre chamadas). Com dois modelos e três parametrizações, o volume de chamadas do eval
multiplicou. *Decisão:* retry com back-off no núcleo da Sprint 03 (`with_retry`, 3 tentativas),
pausa de 5 s entre casos, persistência de cada bloco de resultado em JSON assim que termina e
runner parcial (`--seguranca`, `--memoria`, `--parametros`) que mescla com o consolidado anterior,
para que uma falha no meio não obrigue a refazer tudo. *Porquê:* eval que não termina não vira
evidência.

**Problema 4 — Ausência dos PDFs quebrava o pipeline fora do Kaggle.**
O caminho dos PDFs estava fixo no notebook da Sprint 2 e o notebook não rodava no Colab nem
localmente. *Decisão:* `GOODWE_PDF_DIR` por variável de ambiente, varredura da pasta em vez de
nomes fixos de arquivo, e corpus de contingência versionado. *Porquê:* o professor precisa
conseguir executar o repositório sem montar o dataset.

## 5. Equipe e divisão do trabalho

| Nome | RM | Tarefa principal |
|---|---|---|
{equipe_md}

Autoria por integrante: histórico Git do repositório (`git shortlog -sne`).
"""


# ──────────────────────────────────────────────────────────────────────────────
def markdown_para_pdf(caminho_md: Path, caminho_pdf: Path) -> bool:
    """Converte via pandoc + wkhtmltopdf (HTML intermediário, para as tabelas renderizarem bem)."""
    css = caminho_md.parent / "_relatorio.css"
    css.write_text(
        """
        @page { size: A4; margin: 18mm 16mm; }
        body { font-family: "DejaVu Sans", Arial, sans-serif; font-size: 9.5pt; line-height: 1.38; color: #1a1a1a; }
        h1 { font-size: 16pt; color: #14315c; border-bottom: 2px solid #14315c; padding-bottom: 4px; }
        h2 { font-size: 12pt; color: #14315c; margin-top: 14px; page-break-after: avoid; }
        h3 { font-size: 10.5pt; color: #14315c; page-break-after: avoid; }
        table { border-collapse: collapse; width: 100%; font-size: 8.3pt; margin: 8px 0; page-break-inside: avoid; }
        thead { display: table-header-group; }
        tr, td, th { page-break-inside: avoid; }
        th { background: #14315c; color: #fff; text-align: left; }
        th, td { border: 1px solid #b9c2cf; padding: 3.5px 5px; vertical-align: top; }
        tr:nth-child(even) td { background: #f4f6f9; }
        code { background: #eef1f5; padding: 0 2px; font-size: 8.3pt; }
        blockquote { border-left: 3px solid #d0a215; background: #fdf8e8; padding: 4px 10px; margin: 8px 0; }
        p, li { margin: 3px 0; }
        """,
        encoding="utf-8",
    )
    html = caminho_md.with_suffix(".html")
    try:
        subprocess.run(
            ["pandoc", str(caminho_md), "-s", "--css", css.name, "-o", str(html),
             "--metadata", "lang=pt-BR", "--metadata", "pagetitle=Relatório de evolução — Sprint 03"],
            check=True, cwd=caminho_md.parent,
        )
        subprocess.run(
            ["wkhtmltopdf", "--enable-local-file-access", "--encoding", "utf-8",
             "--title", "Relatório de evolução do projeto — Sprint 03 — GoodWe Assist",
             "--margin-top", "14mm", "--margin-bottom", "14mm", str(html), str(caminho_pdf)],
            check=True, cwd=caminho_md.parent,
        )
        html.unlink(missing_ok=True)
        css.unlink(missing_ok=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError) as erro:
        print(f"  ⚠️  Conversão para PDF indisponível ({erro}). O markdown foi gerado normalmente.")
        return False


def main() -> None:
    cons = reconstruir_consolidado()
    if cons is None:
        print("ℹ️  Nenhum resultado em results/ — gerando versão PRELIMINAR.")
    else:
        faltas = pendencias(cons)
        print("ℹ️  Pendências:" if faltas else "✅ Todos os blocos medidos.")
        for f in faltas:
            print(f"   · {f}")

    DIR_DOCS.mkdir(exist_ok=True)

    md_modelos = DIR_DOCS / "relatorio_modelos.md"
    md_modelos.write_text(gerar_relatorio_modelos(cons), encoding="utf-8")
    print(f"  ✅ {md_modelos}")

    md_seg = DIR_DOCS / "resultados_seguranca.md"
    md_seg.write_text(gerar_resultados_seguranca(cons), encoding="utf-8")
    print(f"  ✅ {md_seg}")

    md_evolucao = DIR_DOCS / "relatorio_evolucao_sprint03.md"
    md_evolucao.write_text(gerar_relatorio_evolucao(cons), encoding="utf-8")
    print(f"  ✅ {md_evolucao}")

    pdf = DIR_DOCS / "relatorio_evolucao_sprint03.pdf"
    if markdown_para_pdf(md_evolucao, pdf):
        print(f"  ✅ {pdf}")


if __name__ == "__main__":
    main()
